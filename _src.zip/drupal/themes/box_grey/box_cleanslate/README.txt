
box_cleanslate variant for box_grey theme
-----------------------------------------

This is a theme variation, it uses the box_grey tpl files, but a seperate stylsheet and logo, and must remain as a subfolder of box_grey. It's an example of how to make Drupal themes purely by modifying a CSS stylesheet.

This style is essentially the phptemplate cleanslate theme moved onto the box_grey template. It's not identical to cleanslate but uses the same colours and similar borders.

See the box_grey README for full details


Author
------
adrinux
mailto: adrinux@ gmail.com
IM: perlucida

Known Problems
--------------
See the box_grey README
