Hi there,

If you are reading this then it is likely that you wish to install the version of Drupal that I worked on in the development of the book. In all likelihood THIS IS NOT THE LATEST VERSION OF DRUPAL AVAILABLE! You may experience version problems if you try extend this source...

I recommend that you only install this if there is anything specific you wish to look at and work with. Otherwise, please build up the site as you follow along in the book on whatever version of Drupal is most appropriate for you.

If you do intend to use this version then, until you set a new administration password, you will need to use the following username and password in order to administer the site:

username: david mercer
password: drupal_b00k

The backup of the database is contained in the database directory within the file download and the file is called: drupalbook_backup.sql. Simply use this if you wish to make use of my settings - there are a bunch of dummy posts and so on that you will no doubt want to get rid of.

Good luck with your Drupal project and I hope that you find the book to be of great value...

Kind regards,
David Mercer