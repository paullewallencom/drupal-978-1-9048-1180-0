This is a simple module to create blocks based on taxonomy. It displays listings of recently posted nodes based on taxonomy definitions. You can create as many blocks as you like.

Send comments to welch@advomatic.com

Originally developed for stagespace.com by Aaron Welch (crunchywelch) at Advomatic LLC
