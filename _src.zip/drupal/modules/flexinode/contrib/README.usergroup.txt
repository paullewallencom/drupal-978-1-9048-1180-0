This flexinode field addition allows you to choose any of your defined user
roles, of which users assigned to those roles will then be displayed in a
dropdown menu on the content submission form. 

This addition was made during the exploration and customization of
Drupal by http://www.NHPR.org. In loving support of open source software,
http://www.NHPR.org will continue to contribute code they feel the
community will benefit from. Questions about this code should be
directed to morbus@disobey.com.
