This a flexible table: you do not need to specify number of
columns and rows.

In the beginning, it gives you 8x5 textareas.

The first row and the first column is reserved for headers.

If a header is empty, the corresponding column/row is not stored.

If you edit an existing table, it always appends an empty column and an
empty row. If you leave the headers, these are not stored, but if you
want to for eg. add a column, just fill the headers.

If you have any questions, suggestions etc. contact me: 

Karoly Negyesi
chx mail tvnet hu
   @    .     .
