This field type was initially built into the civicspace version of event.module. It allows you to associate image galleries with a node. When viewing the node, links to the gallery pages appear.

You should have to copy this file into the modules/flexinode directory to use it, but as of 01/05/2005 this is not the case.

Contact welch@advomatic.com with comments.
