To use fields of type url, copy the file field_url.inc to the
folder modules/flexinode of your Drupal installation.
