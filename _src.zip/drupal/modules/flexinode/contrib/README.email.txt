To use fields of type email, copy the file field_email.inc to the
folder modules/flexinode of your Drupal installation.
