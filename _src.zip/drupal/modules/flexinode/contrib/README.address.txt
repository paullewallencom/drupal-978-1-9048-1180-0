This flexinode field extension provides a data structure for postal 
addresses.  The address has three lines which are followed by fields
for city, state, postal code, and country.  The labels for the fields
can be translated.  The essential things are themeable.

Nic Ivy (njivy)
