INSTALLATION

Copy the colorpickerform.inc and the field_colorpicker.inc into the flexinode directory.

The form_colorpicker() in colorpickerform.inc would theoretically be a candidate for inclusion in 
common.inc, thus the function_exists check in field_colorpicker.inc.  

POSSIBLE USES

I am hoping that this will be useful in granting users control over the styles of their sites. I can
imagine a flexinode with several color pickers, select boxes and check boxes that could be used to 
override the default styles of a theme for that particular user.


CONTACT

Robert Douglass
rob@robshouse.net