This field type allows you to associate image galleries with a node chosing them from the dropdown menu.
When viewing the node, shows the images thumbs using functions from the image module.
For example: http://odessatur.ru/node/21

For any comments. please, contact Chaplygin Anton <ustas@it-arts.ru>