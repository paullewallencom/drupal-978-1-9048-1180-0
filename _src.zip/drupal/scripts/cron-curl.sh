#!/bin/sh
# $Id: cron-curl.sh,v 1.2 2005/08/11 13:02:08 dries Exp $

curl --silent --compressed http://yoursite.com/cron.php
